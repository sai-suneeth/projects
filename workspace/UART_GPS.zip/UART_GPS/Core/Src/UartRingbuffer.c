/*
 * UartRingbuffer.c
 *
 *
 */
#include <string.h>
#include "stm32f401ccu6_hal.h"
#include "UartRingbuffer.h"





/******************* Ring Buffer Definition *******************/



typedef struct {
    uint8_t buffer[UART_BUFFER_SIZE];
    volatile uint16_t head;
    volatile uint16_t tail;
}ring_buffer;







ring_buffer rx_buffer = { { 0 }, 0, 0};
ring_buffer tx_buffer = { { 0 }, 0, 0};

ring_buffer *_rx_buffer;
ring_buffer *_tx_buffer;

/******************* Ring Buffer Functions *******************/

void Ringbuf_init(void)
{
    _rx_buffer = &rx_buffer;
    _tx_buffer = &tx_buffer;
}

void store_char(unsigned char c, ring_buffer *buffer)
{
    int i = (buffer->head + 1) % UART_BUFFER_SIZE;

    if(i != buffer->tail) {
        buffer->buffer[buffer->head] = c;
        buffer->head = i;
    }
}

int Uart_read(void)
{
    if(_rx_buffer->head == _rx_buffer->tail)
    {
        return -1;
    }
    else
    {
        unsigned char c = _rx_buffer->buffer[_rx_buffer->tail];
        _rx_buffer->tail = (_rx_buffer->tail + 1) % UART_BUFFER_SIZE;
        return c;
    }
}

void Uart_write(int c)
{
    if (c >= 0)
    {
        int i = (_tx_buffer->head + 1) % UART_BUFFER_SIZE;
        while (i == _tx_buffer->tail) {} // Wait until space is available in the buffer

        _tx_buffer->buffer[_tx_buffer->head] = (uint8_t)c;
        _tx_buffer->head = i;

        __HAL_UART_ENABLE_IT(uart, UART_IT_TXE); // Enable UART transmission interrupt
    }
}

/******************* UART ISR Handling *******************/

/* HAL_UART_RxCpltCallback function */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == &huart2) {
        unsigned char c = huart->Instance->DR; // Read the received data from UART data register
        store_char(c, _rx_buffer); // Store data in the ring buffer
    }
}

/* HAL_UART_TxCpltCallback function */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == &huart2) {
        if (_tx_buffer->head != _tx_buffer->tail) { // Check if there's more data in the output buffer
            unsigned char c = _tx_buffer->buffer[_tx_buffer->tail]; // Get the next byte to transmit from the buffer
            _tx_buffer->tail = (_tx_buffer->tail + 1) % UART_BUFFER_SIZE; // Move the tail
            huart->Instance->DR = c; //
        } else {
            __HAL_UART_DISABLE_IT(huart, UART_IT_TXE);
        }
    }
}


