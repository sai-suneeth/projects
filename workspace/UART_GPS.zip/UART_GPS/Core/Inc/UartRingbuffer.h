/*
 * UartRingbuffer.h
 *
 *  Created on: Apr 4, 2024
 *      Author: sakku
 */

#ifndef UART_RINGBUFFER_H
#define UART_RINGBUFFER_H

#include <stdint.h>

/******************* Ring Buffer Definition *******************/

#define UART_BUFFER_SIZE 512

typedef struct {
    uint8_t buffer[UART_BUFFER_SIZE];
    volatile uint16_t head;
    volatile uint16_t tail;
} ring_buffer;

void Ringbuf_init(void);
void store_char(unsigned char c, ring_buffer *buffer);
int Uart_read(void);
void Uart_write(int c);

#endif /* UART_RINGBUFFER_H */

