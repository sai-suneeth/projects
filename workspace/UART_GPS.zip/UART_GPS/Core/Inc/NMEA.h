/*
 * NMEA.h
 *
 *  Created on: Apr 3, 2024
 *      Author: sakku
 */

/*
 * NMEA.h
 *
 *  Created on: Apr 3, 2024
 *      Author: sakku
 */

#ifndef NMEA_H_
#define NMEA_H_

#include <stdint.h>

#define NMEA_MAX_MESSAGE_SIZE 128

typedef struct {
    char gpsposition;
    float timestamp;
    float latitude;      // decimal degrees
    char Northorsouth;
    float longitude;     // decimal degrees
    char eastorwest;
    char fix_type;       // Type of fix (e.g., 'A' for autonomous, 'D' for differential)
    float satellites;
    float hdop;
    float altitude;      // meters
    float VDOP;
} NMEA_Data;

void parseNMEA(const char *message, NMEA_Data *data);



#endif /* NMEA_H_ */
